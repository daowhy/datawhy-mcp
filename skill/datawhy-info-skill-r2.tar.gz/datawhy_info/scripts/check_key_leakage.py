#!/usr/bin/env python3
"""AT-14 敏感输出检查器（集中复核 R1 CR-04）。

在内存中读取 DAC_API_KEY（不进入命令历史），扫描指定目录文本文件，
仅输出匹配数与脱敏位置（文件:行号:列区间），不输出原行内容。
用法：python3 check_key_leakage.py <目录或文件>...
退出码：0=零匹配（完整扫描）；1=有匹配；2=未设置 DAC_API_KEY；3=检查不完整（无目标/不存在/读失败/零文件——不得当通过）。
"""
import os
import sys


def main() -> int:
    key = os.environ.get("DAC_API_KEY", "").strip()
    if not key:
        print("未设置 DAC_API_KEY（仅内存读取，不入命令历史）", file=sys.stderr)
        return 2
    targets = sys.argv[1:]
    if not targets:
        print("错误: 未指定扫描目标（必填：会话输出目录或文件）", file=sys.stderr)
        print("用法: check_key_leakage.py <目录或文件>...", file=sys.stderr)
        return 2
    hits = 0
    scanned = 0
    incomplete = False
    reasons = []
    for target in targets:
        if os.path.isfile(target):
            files = [target]
        elif os.path.isdir(target):
            files = []
            for root, _dirs, names in os.walk(target):
                files.extend(os.path.join(root, n) for n in names
                             if n.endswith((".log", ".txt", ".json", ".csv", ".md")))
        else:
            incomplete = True
            reasons.append(f"目标不存在: {target}")
            continue
        if not files:
            incomplete = True
            reasons.append(f"目标无可扫描文件: {target}")
            continue
        for path in files:
            try:
                with open(path, encoding="utf-8", errors="replace") as handle:
                    for lineno, line in enumerate(handle, 1):
                        col = line.find(key)
                        if col >= 0:
                            hits += 1
                            # 脱敏位置：仅输出区间，不输出内容
                            print(f"MATCH: {path}:{lineno}:col{col + 1}-{col + len(key)}（长度 {len(key)}）")
                scanned += 1
            except OSError as exc:
                incomplete = True
                reasons.append(f"无法读取: {path}（{type(exc).__name__}）")
    if scanned == 0 or incomplete:
        # R2-04：检查不完整（无目标/不存在/读失败/零文件扫描）不得输出 PASS
        print("检查不完整：", file=sys.stderr)
        for r in reasons:
            print(f"  - {r}", file=sys.stderr)
        if scanned == 0:
            print("  - 未扫描任何文件", file=sys.stderr)
        print(f"已扫描文件: {scanned}；已命中: {hits}（本次结果不可作为通过依据）")
        return 3
    print(f"总计匹配: {hits}（已扫描 {scanned} 个文件）")
    return 0 if hits == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
