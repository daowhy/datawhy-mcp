#!/usr/bin/env python3
"""market-data-api 客户端（ZC-STKSK-003 权威源码，三套 Skill 共用）。

仅依赖 Python 标准库。只调用本文件内白名单 API 路径，不提供 SSH/数据库
直连能力，不读取除 DAC_API_KEY / DAC_API_BASE / DAC_API_ALLOW_HTTP 之外
的任何敏感信息；API Key 不出现在日志、错误消息或命令示例中。

安全与重试策略（与 G2 冻结契约一致）：
- 入口必须显式配置 DAC_API_BASE（生产为 https://... ）；缺失或非 HTTPS
  时拒绝执行（本地联调可用 DAC_API_ALLOW_HTTP=1 显式放行 http://127.0.0.1）。
- 401/403（凭证/权限）、daily_quota_exceeded（日额度耗尽）、503：不重试，
  解释原因后退出。
- 429 rate_limit_exceeded：仅对幂等 GET 请求做一次 2 秒退避重试；再次 429
  即退出。下载创建（POST）不做任何自动重试——结果不确定时提示先用
  download list 查找已有任务。
- 3xx 重定向一律拒绝（不自动跟随），避免 X-API-Key 被带到跨来源地址；
  POST 不会因 301/302/303 被隐式改写重发。
- cursor_expired / invalid_cursor：提示从首页重新获取（有界重新开始），
  不自动循环翻页。
- 分页与下载轮询均由用户显式推进（--page / --cursor；下载状态不自动轮询，
  无 --wait 参数），不自动遍历全库。
- 兼容两种错误结构：AppError {"error":{"code","message"}} 与 FastAPI
  422/HTTPException 的 {"detail": 字符串或数组}。
"""
import argparse
import json
import os
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

PROD_BASE_HINT = "https://info.timelibrary.net"

# 路由白名单（CR-03）：method + 精确路由模板；{dataset_code}/{task_id} 为受检参数。
# needs_key 由本表决定，不再用路径前缀推断。
ROUTES = (
    ("GET", "/api/v1/portal/query-specs", False),
    ("GET", "/api/v1/portal/datasets", False),
    ("GET", "/api/v1/portal/datasets/{dataset_code}/fields", False),
    ("GET", "/api/v1/portal/datasets/{dataset_code}/samples", False),
    ("GET", "/api/v1/market/query/{dataset_code}", True),
    ("GET", "/api/v1/market/snapshot", True),
    ("GET", "/api/v1/market/quotes", True),
    ("GET", "/api/v1/market/kline/daily", True),
    ("GET", "/api/v1/market/kline/minute", True),
    ("GET", "/api/v1/market/calendar", True),
    ("GET", "/api/v1/market/adjust-factor", True),
    ("GET", "/api/v1/signal/daily", True),
    ("GET", "/api/v1/usage/summary", True),
    ("POST", "/api/v1/downloads", True),
    ("GET", "/api/v1/downloads", True),
    ("GET", "/api/v1/downloads/{task_id}", True),
    ("GET", "/api/v1/downloads/{task_id}/file", True),
    ("DELETE", "/api/v1/downloads/{task_id}", True),
)

import re as _re

_DATASET_CODE_RE = _re.compile(r"^[A-Za-z0-9_-]{1,64}$")


class ApiCallError(RuntimeError):
    def __init__(self, message, code=None, status=None):
        super().__init__(message)
        self.code = code
        self.status = status


def _normalize_error_code(raw):
    """R2-01：任意原始错误码规范化为已知白名单字符串或 unknown_error。

    对象/数组/数字/null/非字符串一律 unknown_error（不抛 TypeError）；
    字符串仅在白名单内透传——正则不做敏感性证明，白名单才是边界。
    """
    if not isinstance(raw, str):
        return "unknown_error"
    return raw if raw in _KNOWN_ERROR_HINTS else "unknown_error"


# 已知稳定错误码 → 固定安全说明（CR-01：唯一自由文本出口收敛点）
_KNOWN_ERROR_HINTS = {
    "daily_quota_exceeded": "日额度已耗尽：今天不再自动重试；可用 `usage` 查看用量，明天额度重置后再试。",
    "missing_api_key": "API Key 缺失或无效：请检查 DAC_API_KEY 配置。",
    "invalid_api_key": "API Key 无效或已撤销：请到门户个人中心重新创建。",
    "api_key_expired": "API Key 已过期：请到门户个人中心更新。",
    "api_user_inactive": "属主账号被禁用：请联系管理员。",
    "subscription_required": "无有效订阅：请联系管理员分配套餐。",
    "plan_inactive": "套餐已停用：请联系管理员。",
    "domain_not_allowed": "当前套餐不包含该数据域。",
    "api_scope_denied": "当前 Key 无该接口权限：请联系管理员调整 scope。",
    "ip_not_allowed": "当前 IP 不在 Key 白名单：请联系管理员。",
    "batch_symbol_limit": "请求标的数超套餐限制：请减少标的。",
    "history_limit": "请求历史区间超套餐限制：请缩小范围。",
    "rate_limit_exceeded": "请求频率超限：请降低调用频率后重试。",
    "dataset_not_supported": "产品不存在或暂不支持在线查询：以 `discover` 查看当前产品清单为准。",
    "dataset_not_published": "产品未发布或已下架：以 `discover` 查看当前可查询产品为准。",
    "no_data": "当前条件未查询到数据：请检查证券代码、日期区间与周期；空结果不代表数值为 0。",
    "symbol_required": "缺少必填证券代码参数。",
    "invalid_symbol": "证券代码格式非法。",
    "invalid_date_format": "日期格式非法（YYYY-MM-DD）。",
    "invalid_date_range": "日期区间非法（倒置或超限）。",
    "invalid_period": "周期参数非法。",
    "invalid_page": "页码非法。",
    "invalid_page_size": "每页条数非法。",
    "invalid_sort_field": "排序字段非法。",
    "invalid_sort_order": "排序方向非法。",
    "query_timeout": "查询超时：请缩小范围后重试。",
    "query_backend_error": "后端查询异常：请稍后重试。",
    "download_scope_denied": "当前 Key 未开通下载权限：需要管理员为 Key 显式开通 download 动作授权。",
    "download_disabled": "下载服务暂未启用：请联系管理员。",
    "download_not_found": "下载任务不存在或不属于当前用户。",
    "download_not_ready": "文件尚未生成：请稍后查看状态。",
    "download_expired": "下载文件已过期：请重新创建任务。",
    "download_not_cancellable": "当前状态不可取消。",
    "download_history_limit_exceeded": "历史区间超出当前套餐限制：请缩小范围后重新创建。",
    "download_row_limit_exceeded": "结果超过行数上限：请缩小日期或证券范围后重新创建。",
    "download_params_invalid": "任务参数异常：请修正后重新创建。",
    "invalid_cursor": "分页游标无效：请从首页重新开始；游标为不透明 token，不要自行构造。",
    "cursor_expired": "分页游标已过期：请从首页（不带 cursor）重新开始翻页。",
    "api_rate_temporarily_unavailable": "服务暂时不可用：请稍后重试（非频率问题，勿反复重试）。",
    "api_rate_backend_unavailable": "服务暂时不可用：请稍后重试或联系管理员。",
    "download_cursor_unavailable": "服务端游标配置异常：请联系管理员。",
    "download_terminal_state": "文件不可领取（终态）：请查看任务状态说明，按需重新创建下载任务。",
    "download_failed": "导出执行失败：请重试；若持续失败请联系管理员并提供任务号。",
    "cancelled_by_user": "任务被用户取消。",
    "redirect_rejected": None,  # 已在 call_api 内固定文案
    # 本地生成码（非服务端，可安全透出）
    "network_error": None,
    "config_missing": None,
    "config_invalid": None,
    "config_insecure": None,
    "path_not_whitelisted": None,
    "stkinfo_query_unavailable": None,
    "validation_error": None,
}


def _parse_error_body(body_text):
    """双兼容错误结构（R2-01：返回的 code 已规范化；message 仅供内部丢弃）。

    原始 message/body 不进入任何输出通道——本函数返回 message 仅用于
    call_api 内部记录，不再拼接进异常文本。
    """
    try:
        payload = json.loads(body_text) if body_text else {}
    except (ValueError, TypeError):
        return ("", "unknown_error")
    if isinstance(payload, dict) and isinstance(payload.get("error"), dict):
        err = payload["error"]
        raw_code = err.get("code")
        return ("", _normalize_error_code(raw_code))
    detail = payload.get("detail") if isinstance(payload, dict) else None
    if isinstance(detail, list):
        return ("", "validation_error")
    if isinstance(detail, str) and detail:
        return ("", "unknown_error")
    return ("", "unknown_error")


_LOOPBACK_HOSTNAMES = ("127.0.0.1", "localhost", "::1")


def _base_url(allow_hint=True):
    """解析并校验 DAC_API_BASE（CR-01 严格口径）。

    生产仅接受完整 HTTPS origin；本地 HTTP 仅在 DAC_API_ALLOW_HTTP=1 且解析后
    hostname 精确等于 loopback（127.0.0.1/localhost/::1）时放行。拒绝 userinfo、
    空主机名、相似后缀域名、非根路径、query/fragment 与非法端口。
    """
    from urllib.parse import urlsplit

    raw = (os.getenv("DAC_API_BASE") or "").strip()
    if not raw:
        raw = _config_fallback("DAC_API_BASE") or ""
    if not raw:
        hint = f"（生产入口示例：{PROD_BASE_HINT}）" if allow_hint else ""
        raise ApiCallError(
            f"未配置 DAC_API_BASE。排查顺序同 DAC_API_KEY（环境变量→注册表→.env）。"
            f"请设置为数据门户 HTTPS 入口{hint}。", code="config_missing")
    try:
        parts = urlsplit(raw)
        port = parts.port  # 非法端口在此抛 ValueError
    except ValueError as exc:
        raise ApiCallError(f"DAC_API_BASE 端口非法: {exc}", code="config_invalid")
    hostname = (parts.hostname or "").lower().strip("[]")
    problems = []
    if parts.scheme == "https":
        pass
    elif parts.scheme == "http":
        if os.getenv("DAC_API_ALLOW_HTTP") != "1":
            problems.append("非 HTTPS 入口（本地联调可为 loopback 设置 DAC_API_ALLOW_HTTP=1）")
        elif hostname not in _LOOPBACK_HOSTNAMES:
            problems.append(f"HTTP 仅允许 loopback（127.0.0.1/localhost/::1），当前: {hostname or '空'}")
    else:
        problems.append(f"scheme 必须为 https（本地联调可为 http），当前: {parts.scheme or '空'}")
    if parts.username or parts.password:
        problems.append("不允许携带用户信息（user:pass@）")
    if not hostname:
        problems.append("缺少主机名")
    if parts.path not in ("", "/"):
        problems.append(f"入口不应包含路径: {parts.path}")
    if parts.query or parts.fragment:
        problems.append("入口不应包含 query 或 fragment")
    if port is not None and not (1 <= port <= 65535):
        problems.append(f"端口超范围: {port}")
    if problems:
        raise ApiCallError("DAC_API_BASE 无效: " + "；".join(problems), code="config_insecure")
    return raw.rstrip("/")


def _config_fallback(name):
    """C2 报告 P0-2：进程环境缺失时的凭证回退链——
    Windows 注册表 HKCU\Environment → 技能目录 .env（KEY=VALUE 行）。
    只返回值本身，不打印；两处都取不到返回 None。"""
    if sys.platform == "win32":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
                v, _ = winreg.QueryValueEx(k, name)
                v = (v or "").strip()
                if v:
                    return v
        except OSError:
            pass
    env_file = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env")
    try:
        with open(env_file, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line.startswith(name + "="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
    except OSError:
        pass
    return None


def _api_key():
    api_key = (os.getenv("DAC_API_KEY") or "").strip()
    if not api_key:
        api_key = _config_fallback("DAC_API_KEY") or ""
    if not api_key:
        raise ApiCallError(
            "未配置 DAC_API_KEY。排查顺序：① 会话环境变量 export DAC_API_KEY=…；"
            "② Windows 用户环境变量（注册表 HKCU\\Environment，设置后需新开会话）；"
            "③ skill 目录 .env 文件（DAC_API_KEY=… 一行）。"
            "不要写入脚本或命令示例。", code="config_missing")
    return api_key


def _check_route(method, path):
    """method + 精确路由模板匹配（CR-03）。返回 needs_key。

    静态路由精确匹配；{dataset_code}/{task_id} 按严格格式校验，路径中出现
    ..、反斜线、百分号编码、query/fragment 一律拒绝。
    """
    if any(token in path for token in ("..", "\\", "%", "?", "#")) or "//" in path:
        raise ApiCallError(f"拒绝可疑路径: {path}", code="path_not_whitelisted")
    # CR-02（G3-R2）：单个前导斜线、无尾斜线、无换行/空白，否则直接拒绝。
    if not path.startswith("/") or path.endswith("/") or path != path.strip():
        raise ApiCallError(f"拒绝非标准路径形式: {path}", code="path_not_whitelisted")
    for route_method, template, needs_key in ROUTES:
        if route_method != method:
            continue
        tpl_parts = template.strip("/").split("/")
        path_parts = path[1:].split("/")
        if len(tpl_parts) != len(path_parts):
            continue
        matched = True
        for tpl, seg in zip(tpl_parts, path_parts):
            if tpl == "{dataset_code}":
                if not _DATASET_CODE_RE.fullmatch(seg):
                    matched = False
                    break
            elif tpl == "{task_id}":
                # 仅 ASCII 数字（isdigit 接受 Unicode 数字，int() 可能异常）
                if not seg or not all("0" <= ch <= "9" for ch in seg) or int(seg) == 0:
                    matched = False
                    break
            elif tpl != seg:
                matched = False
                break
        if matched:
            return needs_key
    raise ApiCallError(f"非白名单 API（{method} {path}）", code="path_not_whitelisted")


import http.client
import socket
import urllib.request

from urllib.error import HTTPError, URLError
from urllib.request import HTTPRedirectHandler, OpenerDirector, ProxyHandler

# CR-01（105 复核）：响应读取阶段的【具体】网络异常，逐名列出、不吞未知异常。
# - TimeoutError / socket.timeout：读取超时（3.9 中两者不同类，3.10+ 合并，重复列出无害）；
# - ConnectionError：连接被重置/断开（RemoteDisconnected 属此且属 HTTPException）；
# - http.client.HTTPException：截断/坏状态行等协议层异常；
# - URLError：urllib 请求阶段的包裹型网络错误。
# 注意 HTTPError 是 URLError 子类，必须先被 except HTTPError 分支处理。
_NETWORK_EXCEPTIONS = (URLError, http.client.HTTPException, ConnectionError,
                       TimeoutError, socket.timeout)


class _NoRedirectHandler(HTTPRedirectHandler):
    """CR-02：禁止自动重定向——redirect_request 返回 None 使 3xx 成为 HTTPError。"""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _build_opener():
    opener = OpenerDirector()
    opener.add_handler(ProxyHandler())
    opener.add_handler(_NoRedirectHandler())
    for handler in (urllib.request.HTTPHandler, urllib.request.HTTPSHandler,
                    urllib.request.HTTPDefaultErrorHandler, urllib.request.HTTPErrorProcessor):
        opener.add_handler(handler())
    return opener


def call_api(path, params=None, method="GET", retry_once_on_rate_limit=True, timeout=30,
             raw_text=False):
    """调用白名单 API。params 为查询参数；method 仅支持 GET/POST/DELETE。

    重试策略：幂等 GET 在 429 rate_limit_exceeded 时退避 2 秒重试一次；
    其余错误（401/403/额度耗尽/503/cursor 类）一律不重试，按语义上抛。
    """
    needs_key = _check_route(method, path)
    query = urlencode({k: v for k, v in (params or {}).items() if v not in (None, "", False)}) \
        if method == "GET" else ""
    body = json.dumps(params, ensure_ascii=False).encode("utf-8") if method != "GET" else None
    headers = {"Accept": "application/json"}
    if method != "GET":
        headers["Content-Type"] = "application/json"
    if needs_key:
        headers["X-API-Key"] = _api_key()
    url = f"{_base_url()}{path}" + (f"?{query}" if query else "")

    opener = _build_opener()  # CR-02：禁止自动重定向
    attempt = 0
    while True:
        request = Request(url, data=body, headers=headers, method=method)
        try:
            with opener.open(request, timeout=timeout) as response:
                try:
                    text = response.read().decode("utf-8")
                except _NETWORK_EXCEPTIONS as exc:
                    # CR-01（105）：成功响应【读取阶段】的超时/截断/断开不被 urllib
                    # 包成 URLError——在此收敛为 network_error，不回显 reason，
                    # 不重试（创建类 POST 的“结果不确定”语义只能上抛）。
                    _ = exc
                    raise ApiCallError("", code="network_error", status=None) from exc
                if raw_text:
                    return text
                return json.loads(text) if text else {}
        except HTTPError as exc:
            if 300 <= exc.code < 400:
                raise ApiCallError(
                    f"入口返回重定向（HTTP {exc.code}）：请确认 DAC_API_BASE 指向正确的"
                    " HTTPS 入口；客户端不自动跟随重定向。", code="redirect_rejected") from exc
            http_status = exc.code
            try:
                body_text = exc.read().decode("utf-8", errors="replace")  # 仅用于解析，不输出
            except _NETWORK_EXCEPTIONS as read_exc:
                # CR-01（105）：错误响应【体读取阶段】被截断时无法安全解析错误码——
                # 收敛为 network_error（保留已知 HTTP 状态），不猜测、不回显。
                _ = read_exc
                raise ApiCallError("", code="network_error", status=http_status) from read_exc
            _message_discarded, code = _parse_error_body(body_text)
            if (exc.code == 429 and code == "rate_limit_exceeded"
                    and retry_once_on_rate_limit and method == "GET" and attempt == 0):
                attempt += 1
                time.sleep(2)
                continue
            # CR-01：message 不进入异常文本（防泄露）；诊断经 _safe_diagnosis 生成
            raise ApiCallError("", code=code, status=exc.code) from exc
        except _NETWORK_EXCEPTIONS as exc:
            # F-004（AT-12 真实故障注入发现）：请求阶段（含响应头读取）的连接断开、
            # 代理中断等。收敛为 network_error：不回显 reason/内部细节，统一安全诊断。
            _ = exc
            raise ApiCallError("", code="network_error", status=None) from exc


def _safe_diagnosis(status, code, raw_message=None):
    """R2-01 统一安全诊断（唯一出口）：code 已规范化（白名单/unknown）。

    已知码→固定说明；unknown→通用提示（无标识回显——白名单外的任何字符串
    不透出）；本地配置类异常给出操作指引。保留 HTTP status 供定位。
    """
    code = _normalize_error_code(code)
    if code in _LOCAL_HINTS:
        return _LOCAL_HINTS[code]
    if code in _KNOWN_ERROR_HINTS and _KNOWN_ERROR_HINTS[code]:
        return _KNOWN_ERROR_HINTS[code]
    if code == "network_error":
        return "网络错误（请求结果不确定）：请检查入口可达性；对下载创建请勿重发，先用 `download list` 核实。"
    status_part = f"HTTP {status} " if status else ""
    return f"服务返回异常（{status_part}code=unknown_error）：请稍后重试或联系管理员。"


_LOCAL_HINTS = {
    "config_missing": "缺少 DAC_API_BASE 或 DAC_API_KEY。排查顺序：① 会话环境变量 export DAC_API_KEY=…；② Windows 用户环境变量（设置后需新开会话）；③ skill 目录 .env 文件（DAC_API_KEY=… 一行）。",
    "config_invalid": "DAC_API_BASE 配置非法：请检查 scheme/端口格式。",
    "config_insecure": "DAC_API_BASE 被拒绝：生产必须 HTTPS；仅 127.0.0.1/localhost/::1 可用 DAC_API_ALLOW_HTTP=1 本地联调。",
    "path_not_whitelisted": "请求路径不在白名单：本客户端仅调用固定 API，请勿自行拼接路径。",
    "redirect_rejected": "入口返回重定向：请确认 DAC_API_BASE 指向正确的 HTTPS 入口；客户端不跟随重定向。",
    "stkinfo_query_unavailable": "查询服务暂不可用（服务端查询连接未配置）：请联系管理员。",
    "validation_error": "请求参数被拒绝：请检查参数格式（日期 YYYY-MM-DD、代码后缀等）。",
}


def _friendly_error_hint(code):
    hints = {
        "daily_quota_exceeded": "日额度已耗尽：今天不再自动重试；可用 `usage` 查看用量，明天额度重置后再试。",
        "missing_api_key": "API Key 缺失或无效：请检查 DAC_API_KEY 配置。",
        "invalid_api_key": "API Key 无效或已撤销：请到门户个人中心重新创建。",
        "api_key_expired": "API Key 已过期：请到门户个人中心更新。",
        "rate_limit_exceeded": "请求频率超限：请降低调用频率后重试。",
        "dataset_not_published": "产品未发布或已下架：以 `discover` 查看当前可查询产品为准。",
        "dataset_not_supported": "产品不存在或暂不支持在线查询：以 `discover` 查看当前产品清单。",
        "no_data": "当前条件未查询到数据：请检查证券代码、日期区间与周期；空结果不代表数值为 0。",
        "download_scope_denied": "当前 Key 未开通下载权限：需要管理员为 Key 显式开通 download 动作授权。",
        "cursor_expired": "分页游标已过期：请从首页（不带 cursor）重新开始翻页。",
        "invalid_cursor": "分页游标无效：请从首页重新开始；游标为不透明 token，不要自行构造。",
        "api_rate_temporarily_unavailable": "服务暂时不可用：请稍后重试（非频率问题，勿反复重试）。",
        "api_rate_backend_unavailable": "服务暂时不可用：请稍后重试或联系管理员。",
        "download_cursor_unavailable": "服务端游标配置异常：请联系管理员。",
        "network_error": "请求结果不确定：对下载创建请勿直接重发，先用 `download list` 查找是否已创建。",
    }
    return hints.get(code)


def _emit(payload):
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))


def _run_and_emit(fn):
    try:
        _emit(fn())
        return 0
    except ApiCallError as exc:
        # R2-01：exc.code 可能是任意服务端值——先规范化再决定是否显示
        safe_code = _normalize_error_code(exc.code)
        status = f"HTTP {exc.status} " if exc.status else ""
        label = f"（{safe_code}）" if safe_code != "unknown_error" else "（code=unknown_error）"
        print(f"错误: {status}请求失败{label}", file=sys.stderr)
        print(f"说明: {_safe_diagnosis(exc.status, exc.code)}", file=sys.stderr)
        return 1


def dataset_path(dataset_code, suffix):
    return f"/api/v1/portal/datasets/{dataset_code}/{suffix}"


def cmd_check(args):
    def run():
        base = _base_url()
        result = {"api_base": base, "https": base.startswith("https://"),
                  "api_key_configured": bool((os.getenv("DAC_API_KEY") or "").strip()),
                  "key_not_echoed": True}
        try:
            specs = call_api("/api/v1/portal/query-specs", retry_once_on_rate_limit=False)
            result["public_catalog_reachable"] = True
            result["query_spec_count"] = len(specs.get("items", []))
        except ApiCallError as exc:
            result["public_catalog_reachable"] = False
            result["catalog_error"] = str(exc)
        if result["api_key_configured"]:
            try:
                usage = call_api("/api/v1/usage/summary", retry_once_on_rate_limit=False)
                item = usage.get("item", {})
                result["authenticated"] = True
                result["plan_code"] = item.get("plan_code")
                result["daily_remaining"] = item.get("daily_remaining")
            except ApiCallError as exc:
                result["authenticated"] = False
                result["auth_error_code"] = _normalize_error_code(exc.code)  # R2-01：规范化
                result["auth_hint"] = _safe_diagnosis(exc.status, exc.code)
        return result
    return _run_and_emit(run)


def cmd_discover(args):
    def run():
        params = {}
        if args.keyword:
            params["keyword"] = args.keyword
        payload = call_api("/api/v1/portal/datasets", params)
        if getattr(args, "compact", False):
            compact = [{"code": it.get("code"), "name": it.get("name"),
                        "coverage": it.get("coverage"), "dataAsOf": it.get("dataAsOf"),
                        "healthStatus": it.get("healthStatus")}
                       for it in payload.get("items", [])]
            return {"items": compact, "_compact_note": f"共 {len(compact)} 个产品；详情用 discover（不带 --compact）"}
        for item in payload.get("items", []):
            status = item.get("status") or item.get("publishStatus")
            if status:
                item["_note"] = f"目录状态: {status}；可查询性以实际请求为准"
        return payload
    return _run_and_emit(run)


def cmd_fields(args):
    def run():
        payload = call_api(dataset_path(args.dataset_code, "fields"))
        if getattr(args, "compact", False):
            items = payload.get("items", [])
            if isinstance(items, list):
                compact = [{"name": it.get("name") or it.get("column"),
                            "type": it.get("dataType") or it.get("type"),
                            "comment": (it.get("comment") or it.get("description") or "")[:60]}
                           for it in items if isinstance(it, dict)]
                return {"dataset": args.dataset_code, "items": compact,
                        "_compact_note": f"共 {len(compact)} 个字段"}
        return payload
    return _run_and_emit(run)


def cmd_quick(args):
    """C2 报告 P1-4：one-shot 组合命令——连通/配置检查+查询一次完成。"""
    def run():
        base = _base_url()          # 触发配置解析与回退链（缺失即明确报错）
        _api_key()
        import datetime as _dt
        end = args.end or _dt.date.today().isoformat()
        start = args.start or (_dt.date.today() - _dt.timedelta(days=max(args.days, 1) - 1)).isoformat()
        params = {
            "symbol": args.symbol, "start_date": start, "end_date": end,
            "page": 1, "page_size": args.limit,
            "sort_by": args.sort_by, "sort_order": "desc",
        }
        payload = call_api(f"/api/v1/market/query/{args.dataset_code}", params)
        meta = payload.get("meta", {})
        columns = payload.get("columns") or []
        rows = payload.get("rows")
        if rows is None:
            # 受控查询响应形态是 items（dict 行，字段名→值）——转为数组行便于表格输出
            items = payload.get("items") or []
            if items and isinstance(items[0], dict) and not columns:
                columns = list(items[0].keys())
            rows = [[it.get(c) for c in columns] for it in items]
        keep = None
        if args.fields:
            alias = {"close": "close_price", "vol": "volume", "volume": "volume",
                     "amount": "amount", "open": "open_price", "high": "high_price",
                     "low": "low_price", "date": "trade_date"}
            want = [alias.get(f.strip().lower(), f.strip()) for f in args.fields.split(",")]
            keep = [c for c in columns if c in want]
            if not keep:
                keep = columns
        shown = rows
        if keep:
            idx = [columns.index(c) for c in keep if c in columns]
            shown = [[r[i] if i < len(r) else None for i in idx] for r in rows]
            head = [c for c in columns if c in keep]
        else:
            head = columns
        out = {"dataset": args.dataset_code, "columns": head,
               "rows": shown, "row_count": len(shown),
               "query_ms": meta.get("queryMs"), "has_more": meta.get("hasMore")}
        if meta.get("hasMore"):
            out["_pagination_hint"] = f"还有更多：--page 2（当前仅展示前 {len(shown)} 行）"
        return out
    return _run_and_emit(run)


def cmd_samples(args):
    return _run_and_emit(lambda: call_api(dataset_path(args.dataset_code, "samples")))


def cmd_query(args):
    def run():
        params = {
            "symbol": args.symbol, "start_date": args.start, "end_date": args.end,
            "period": args.period, "exchange": args.exchange,
            "page": args.page, "page_size": args.page_size,
            "sort_by": args.sort_by, "sort_order": args.sort_order,
        }
        payload = call_api(f"/api/v1/market/query/{args.dataset_code}", params)
        meta = payload.get("meta", {})
        if meta.get("hasMore"):
            payload["_pagination_hint"] = (
                f"还有更多数据：下一页使用 --page {int(args.page) + 1}；"
                "按需翻页，客户端不会自动遍历全库")
        else:
            payload["_pagination_hint"] = "已到最后一页"
        if meta.get("count") == 0:
            payload["_empty_hint"] = "空结果：不代表数值为 0，可能是代码/日期/周期条件不匹配或非交易日"
        return payload
    return _run_and_emit(run)


LEGACY_ENDPOINTS = {
    "snapshot": ("/api/v1/market/snapshot", ["symbol", "limit"]),
    "quotes": ("/api/v1/market/quotes", ["symbols"]),
    "daily": ("/api/v1/market/kline/daily", ["symbol", "start_date", "end_date", "limit"]),
    "minute": ("/api/v1/market/kline/minute", ["symbol", "period", "start_time", "end_time", "limit"]),
    "calendar": ("/api/v1/market/calendar", ["exchange", "start_date", "end_date", "trading_only", "limit"]),
    "adjust-factor": ("/api/v1/market/adjust-factor", ["symbol", "limit"]),
    "signal": ("/api/v1/signal/daily", ["symbol", "limit"]),
}


def cmd_legacy(args):
    def run():
        path, keys = LEGACY_ENDPOINTS[args.resource]
        mapping = {
            "symbol": args.symbol, "symbols": args.symbols, "period": args.period,
            "exchange": args.exchange, "start_date": args.start, "end_date": args.end,
            "start_time": args.start, "end_time": args.end,
            "trading_only": str(args.trading_only).lower(), "limit": args.limit,
        }
        params = {k: mapping[k] for k in keys}
        payload = call_api(path, params)
        if payload.get("meta", {}).get("count") == 0:
            payload["_empty_hint"] = "空结果：不代表数值为 0；该产品也可能已下架（见错误说明）"
        return payload
    return _run_and_emit(run)


def cmd_usage(_args):
    return _run_and_emit(lambda: call_api("/api/v1/usage/summary"))


def _sanitize_task_items(payload):
    """CR-01（G3-R2）：status/list 输出剔除自由文本 error_message，仅保留
    error_code（安全码表）与业务字段；正常业务数据不改写。"""
    items = payload.get("items") if isinstance(payload, dict) else None
    if items is None and isinstance(payload, dict) and isinstance(payload.get("item"), dict):
        items = [payload["item"]]
    for item in items or []:
        if isinstance(item, dict):
            item.pop("error_message", None)
            code = item.get("error_code")
            if code is not None:
                item["error_code"] = _normalize_error_code(code)  # R2-01：白名单规范化（含对象/数组安全）
    return payload


def cmd_download(args):
    def create():
        params = {
            "dataset_code": args.dataset_code, "symbol": args.symbol,
            "start_date": args.start, "end_date": args.end,
            "period": args.period, "exchange": args.exchange,
        }
        # 创建不做自动重试：网络错误时 call_api 抛 network_error，提示用 list 查找。
        return call_api("/api/v1/downloads", params, method="POST",
                        retry_once_on_rate_limit=False)
    def list_tasks():
        params = {"limit": args.limit}
        if args.cursor:
            params["cursor"] = args.cursor
        payload = _sanitize_task_items(call_api("/api/v1/downloads", params))
        if payload.get("next_cursor"):
            payload["_pagination_hint"] = (
                "下一页：--cursor <next_cursor>（不透明 token，原样使用；"
                "cursor_expired/invalid_cursor 时从首页重新开始）")
        return payload
    def status():
        return _sanitize_task_items(call_api(f"/api/v1/downloads/{args.task_id}"))
    def cancel():
        return call_api(f"/api/v1/downloads/{args.task_id}", method="DELETE")
    # CR-01（G3-R2）：错误摘要仅输出已知安全错误码的固定说明；未知内部错误
    # 返回通用提示与 task_id，不回显 error_message（防泄露 Key/路径/堆栈）。
    _SAFE_TASK_ERROR_HINTS = {
        "download_row_limit_exceeded": "结果超过行数上限：请缩小日期或证券范围后重新创建",
        "download_history_limit_exceeded": "历史区间超出当前套餐限制：请缩小范围后重新创建",
        "download_disabled": "下载服务暂未启用：请联系管理员",
        "download_failed": "导出执行失败：请重试；若持续失败请联系管理员并提供任务号",
        "query_timeout": "导出查询超时：请缩小范围后重新创建",
        "query_backend_error": "后端查询异常：请稍后重试",
        "cancelled_by_user": "任务被用户取消",
    }

    def _safe_failure_hint(item):
        code = _normalize_error_code(item.get("error_code"))
        if code in _SAFE_TASK_ERROR_HINTS:
            return f"任务失败（{code}）：{_SAFE_TASK_ERROR_HINTS[code]}"
        return "任务失败（内部错误，code=unknown_error）：详情请通过管理员按任务号核实；客户端不展示原始错误内容"

    def fetch():
        detail = call_api(f"/api/v1/downloads/{args.task_id}")
        item = detail.get("item", {})
        status = str(item.get("status") or "")
        if not item.get("download_ready"):
            if status in ("queued", "running"):
                return {"ready": False, "status": status,
                        "hint": "任务排队/执行中：稍后用 download status 查看；客户端不自动轮询"}
            terminal = {
                "expired": "文件已过期不可领取：如仍需数据请重新创建下载任务",
                "failed": _safe_failure_hint(item),
                "cancelled": "任务已取消：如仍需数据请重新创建",
                "completed": "任务已完成但文件不可用（可能已被清理）：请重新创建",
            }.get(status, f"未知状态：{status or '空'}，请用 download status 核实")
            print(json.dumps(
                {"ready": False, "status": status or "unknown", "task_id": args.task_id,
                 "hint": terminal},
                ensure_ascii=False, indent=2, default=str))
            raise ApiCallError("文件不可领取（终态）", code="download_terminal_state")
        file_payload = call_api(f"/api/v1/downloads/{args.task_id}/file", timeout=300, raw_text=True)
        out_path = args.out or f"download_{args.task_id}.csv"
        # file_payload 为原始 CSV 文本（非 JSON）时特殊处理
        if isinstance(file_payload, str):
            with open(out_path, "w", encoding="utf-8") as handle:
                handle.write(file_payload)
            return {"ready": True, "saved_to": out_path,
                    "row_count": item.get("row_count"),
                    "hint": "已保存到客户端本地路径"}
        return {"ready": True, "item": item, "note": "文件已就绪但返回了非文本负载", "payload": file_payload}
    actions = {"create": create, "list": list_tasks, "status": status,
               "cancel": cancel, "fetch": fetch}
    return _run_and_emit(actions[args.download_action])


def build_parser():
    parser = argparse.ArgumentParser(
        prog="market_data_client.py",
        description="数据门户 API 客户端（发现/查询/用量/异步下载）")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("check", help="配置与连通性诊断（含 Key 有效性）")
    p.set_defaults(func=cmd_check)

    p = sub.add_parser("discover", help="发现数据产品（公开目录）")
    p.add_argument("--keyword")
    p.add_argument("--compact", action="store_true",
                   help="精简输出：仅 code/name/coverage/dataAsOf/健康状态")
    p.set_defaults(func=cmd_discover)

    p = sub.add_parser("fields", help="查看产品字段字典")
    p.add_argument("dataset_code")
    p.add_argument("--compact", action="store_true",
                   help="精简输出：仅字段名/类型/注释")
    p.set_defaults(func=cmd_fields)

    p = sub.add_parser("quick", help="one-shot 查询：配置检查+按代码/窗口查询一次完成（C2 报告 P1-4）")
    p.add_argument("dataset_code", help="数据产品码（见 discover；常用见 SKILL.md 速查表）")
    p.add_argument("--symbol", required=True, help="证券代码（如 600519.SH / 000300.SH）")
    p.add_argument("--days", type=int, default=10, help="最近 N 个自然日窗口（默认 10）")
    p.add_argument("--fields", default="", help="仅展示这些列（逗号分隔，支持 close/volume 简写）；缺省全部列")
    p.add_argument("--limit", type=int, default=50, help="最大返回行数（默认 50）")
    p.add_argument("--sort-by", default="", help="排序字段（如 trade_date）")
    p.add_argument("--start", default="", help="覆盖起始日（YYYY-MM-DD；缺省按 --days 推算）")
    p.add_argument("--end", default="", help="覆盖截止日（YYYY-MM-DD；缺省今天）")
    p.set_defaults(func=cmd_quick)

    p = sub.add_parser("samples", help="查看产品样例数据")
    p.add_argument("dataset_code")
    p.set_defaults(func=cmd_samples)

    p = sub.add_parser("query", help="统一受限查询（按数据产品）")
    p.add_argument("dataset_code")
    _add_query_params(p)
    p.set_defaults(func=cmd_query)

    p = sub.add_parser("legacy", help="旧专用查询端点（snapshot/quotes/daily/...）")
    p.add_argument("resource", choices=sorted(LEGACY_ENDPOINTS))
    _add_query_params(p)
    p.add_argument("--symbols", default="600519.SH,000001.SZ")
    p.add_argument("--trading-only", action="store_true")
    p.set_defaults(func=cmd_legacy)

    p = sub.add_parser("usage", help="当前 Key 用量与额度摘要")
    p.set_defaults(func=cmd_usage)

    p = sub.add_parser("download", help="异步下载：create/list/status/fetch/cancel")
    sub2 = p.add_subparsers(dest="download_action", required=True)
    p_create = sub2.add_parser("create")
    p_create.add_argument("dataset_code")
    _add_query_params(p_create)
    p_list = sub2.add_parser("list")
    p_list.add_argument("--limit", type=int, default=20)
    p_list.add_argument("--cursor", help="不透明分页游标（来自上一页 next_cursor）")
    p_status = sub2.add_parser("status")
    p_status.add_argument("task_id", type=int)
    p_fetch = sub2.add_parser("fetch")
    p_fetch.add_argument("task_id", type=int)
    p_fetch.add_argument("--out", help="保存的本地文件路径（默认当前目录）")
    p_cancel = sub2.add_parser("cancel")
    p_cancel.add_argument("task_id", type=int)
    p.set_defaults(func=cmd_download)

    return parser


def _add_query_params(p):
    p.add_argument("--symbol")
    p.add_argument("--start")
    p.add_argument("--end")
    p.add_argument("--period")
    p.add_argument("--exchange")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--page-size", dest="page_size", type=int)
    p.add_argument("--sort-by", dest="sort_by")
    p.add_argument("--sort-order", dest="sort_order", choices=["asc", "desc"])
    p.add_argument("--limit", type=int, default=100)


def main(argv=None):
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
        return args.func(args) or 0
    except SystemExit:
        raise
    except KeyboardInterrupt:
        print("已中断", file=sys.stderr)
        return 130
    except Exception as exc:  # C2 报告 P2-6：失败必须可见（stderr + 非零退出码）
        print(f"错误: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
