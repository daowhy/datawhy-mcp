# API 参考（与 G2 冻结契约一致）

入口：`DAC_API_BASE`（生产 `https://info.timelibrary.net`）。鉴权：受保护端点
要求 `X-API-Key` 头；目录发现端点公开。错误结构双兼容：业务错误
`{"error":{"code","message"}}`，框架校验错误为 FastAPI `{"detail": ...}`
（字符串或数组）。

## 公开端点（无需 Key）

| 方法+路径 | 说明 |
|---|---|
| GET /api/v1/portal/query-specs | 查询能力自描述（各产品参数/上限） |
| GET /api/v1/portal/datasets?keyword= | 数据产品目录 |
| GET /api/v1/portal/datasets/{code}/fields | 字段字典（含分级/单位；目录字段≠查询白名单） |
| GET /api/v1/portal/datasets/{code}/samples | 样例（审核通过后展示） |

## 查询端点（X-API-Key）

| 方法+路径 | 说明 |
|---|---|
| GET /api/v1/market/query/{dataset_code} | 统一受限查询（8 类注册产品；symbol/start_date/end_date/period/exchange/page/page_size/sort_by/sort_order） |
| GET /api/v1/market/snapshot · /quotes · /kline/daily · /kline/minute · /calendar · /adjust-factor | 旧专用端点 |
| GET /api/v1/signal/daily | 旧专用（产品未发布时 404 dataset_not_published） |
| GET /api/v1/usage/summary | 当前 Key 用量/额度摘要（不消耗额度；计入 QPS） |

统一查询分页：`page`/`page_size`（服务端上限 100/1000），`meta.hasMore`
指示后续页。空结果为 404 `no_data`（旧专用端点可返回 200+空 items）。

## 异步下载（X-API-Key；需 Key 显式开通 download 动作授权）

| 方法+路径 | 说明 |
|---|---|
| POST /api/v1/downloads | 创建（dataset_code/symbol/start_date/end_date/period/exchange；CSV） |
| GET /api/v1/downloads?limit=&cursor= | 列表（keyset 游标分页） |
| GET /api/v1/downloads/{task_id} | 状态详情 |
| GET /api/v1/downloads/{task_id}/file | 领取 CSV（完成且未过期） |
| DELETE /api/v1/downloads/{task_id} | 取消（queued/running） |

- 列表响应：`items`/`count`（本页数）/`has_more`/`next_cursor`（不透明
  token，原样回传）。单请求扫描有界；预算耗尽的空页 + has_more 表示继续
  翻页可穿过不可见记录。
- 下载不计入行情日额度；保留行数（50 万行上限）、过期（24h）与任务归属
  保护。POST 不做幂等保证：结果不确定先查列表，不盲目重发。

## 关键错误码

`missing_api_key`、`invalid_api_key`、`api_key_expired`、`api_scope_denied`、`download_scope_denied`、
`domain_not_allowed`、`daily_quota_exceeded`（429，额度耗尽）、
`rate_limit_exceeded`（429，频率）、`dataset_not_supported`、
`dataset_not_published`、`no_data`、`invalid_cursor`/`cursor_expired`（400）、
`api_rate_temporarily_unavailable`/`api_rate_backend_unavailable`/
`download_cursor_unavailable`（503）。

额度语义：日额度按用户（跨 Key）汇总、北京日历日 00:00 重置；
`daily_remaining` 为当次请求后的剩余估算。

计数口径（按路径）：
- 分页：每页各计 1 次（每页是独立请求）。
- 统一查询的参数校验失败/执行异常/空结果、网关拒绝（域/scope/批量/历史/
  日额度/QPS）：各计 1 次。
- **发布门禁拒绝（`dataset_not_published`）不计额度**（门禁在计数前执行）。
- Key 认证失败（401）、框架参数校验 422：不计（路由主体未执行）。
- 旧专用端点执行异常：缺少保证失败计数的统一路径。
- 下载与用量摘要不消耗行情日额度（用量摘要计入 QPS）。
客户端应避免无效重试。

## 空值与元数据口径

- 字段为 `null` 或缺失表示**未知/缺失**，不能解释为 0 或自行补写。
- 数据来源、最近更新时间（updatedAt）、时间口径（timeStandard）、单位与
  复权口径，分别以 `discover`/`fields` 与产品页 usageNotes 返回为准，
  不凭常识补写。
