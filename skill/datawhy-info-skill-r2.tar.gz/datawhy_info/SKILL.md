---
name: datawhy_info
description: |-
  Datawhy 行情数据门户 API 客户端：发现数据产品、查询行情、查看用量额度、创建与领取异步下载。通过 HTTPS API Key 访问，不使用数据库直连。
  触发词：「datawhy_info」「查行情数据」「沪深300收盘价」「板块成交额」「行情查询」等。
  常用查询直接用 `quick` 一次完成（见下方速查表），无需先 discover/fields。
---

# datawhy_info · Datawhy 行情数据（ZCode / Claude Code / Codex Skill）

通过 Datawhy 行情数据门户 HTTPS API 使用行情数据。仅调用白名单 API。

## 首次查询（最快路径）

```bash
# 1) 配置（Key 在门户「个人中心 → API Key」创建；Windows 用户环境变量设置后需新开会话）
export DAC_API_BASE="https://info.timelibrary.net"
export DAC_API_KEY="你的API Key"

# 2) one-shot 查询（内部自动完成配置检查+窗口推算+查询）
python3 scripts/market_data_client.py quick trade_index_daily --symbol 000300.SH --days 10 --fields close,vol
```

`--fields` 支持简写：`close→close_price`、`vol→volume`、`open/high/low/amount/date`。

## 常用数据集速查表（13 个产品，低频变动；详单用 discover --compact）

| dataset_code | 名称 | symbol 必填 | symbol 格式 | 常用字段 |
|---|---|---|---|---|
| stock_daily | 股票日线 | 是 | 600519.SH / 000001.SZ | open/high/low/close_price, volume(股), amount(元), turnover_rate(%) |
| trade_index_daily | 市场指数日行情 | 是 | 000300.SH（沪深300）/ 000001.SH（上证） | close_price, amount, change_pct |
| trade_etf_daily | ETF 日行情 | 是 | 510300.SH | close_price, volume |
| quote_snapshot | 实时行情快照 | 是 | 同股票格式 | last_price, prev_close_price |
| stock_info | 证券基础信息 | 否 | — | stock_name, board_name(板块), industry_name(申万二级), concept_tags(概念标签) |
| exchange_calendar | 交易日历 | 否 | — | is_trading_day, is_half_day, holiday_name |
| suspension | 停复牌信息 | 否 | — | suspend_date, resume_date, suspend_reason |
| adjust_factor | 复权因子 | 是 | 同股票格式 | adjust_factor, ratio_adjust_factor |
| etf_component | ETF 成分 | 是 | 510300.SH | component_code, component_name |
| trade_stock_top10_holder | 十大股东 | 是 | 同股票格式 | hold_rank, holder_name, hold_quantity |
| trade_stock_top10_flow_holder | 十大流通股东 | 是 | 同股票格式 | hold_rank, holder_name, hold_quantity |
| trade_stock_holdernum | 股东户数 | 是 | 同股票格式 | shareholder_total |
| stock_minute | 1 分钟行情 | 是 | 同股票格式 | open/high/low/close_price, volume |

**完整命令示例（可直接照抄）**：

```bash
# 股票日线（贵州茅台，最近 10 个自然日，只看收盘价与成交量）
python3 scripts/market_data_client.py quick stock_daily --symbol 600519.SH --days 10 --fields close,vol

# 沪深300 指数（自然日窗口，收盘价+成交额）
python3 scripts/market_data_client.py quick trade_index_daily --symbol 000300.SH --days 10 --fields close_price,amount

# 任意窗口/分页
python3 scripts/market_data_client.py query stock_daily --symbol 600519.SH \
  --start 2026-09-02 --end 2026-09-30 --page 1 --page-size 50 --sort-by trade_date
```

## 凭证存放与排查

读取顺序：**① 会话环境变量 → ② Windows 用户环境变量（注册表 HKCU\Environment，设置后需新开会话）→ ③ 技能目录 .env 文件**（`DAC_API_BASE=…` / `DAC_API_KEY=…` 各一行）。
三处都没有时，`check`/`quick` 会报 config_missing 并给出上述排查顺序。Key 不写入脚本/日志/输出。

## Windows 宿主注意

- 入口命令用 `python scripts/market_data_client.py …`（Windows 无 `python3` 别名）
- 宿主 shell 可能是 cmd.exe：`$VAR` 不展开（用 `%VAR%`）、无 `ls`（用 `dir`）
- 优先使用 `quick` 等子命令（正式入口文件），不要拼 `python -c "…"`（静默失败风险）

## 其他命令

- `check`：配置与连通性诊断（含 Key 有效性）
- `discover [--compact] [--keyword …]`：产品目录（--compact 仅 code/name/覆盖/健康）
- `fields <code> [--compact]`：字段字典
- `samples <code>`：样例数据
- `query <code> …`：统一受限查询（分页显式推进）
- `usage`：当前 Key 用量与额度摘要
- `download create/list/status/fetch/cancel`：异步下载

## 安全

API Key 仅从环境变量/注册表/.env 读取，不写入脚本、日志或命令示例；
不自动跟随重定向；白名单外路径不调用。
